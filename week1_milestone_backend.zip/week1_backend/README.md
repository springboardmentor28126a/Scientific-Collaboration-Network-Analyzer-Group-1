# Scientific Collaboration Network Analyzer — Week 1 Milestone

Covers: Authentication (JWT), User Management, Researcher Profiles, minimal Institutions.

## Setup

1. Create a PostgreSQL database:
   ```bash
   createdb scn_analyzer
   ```

2. Copy `.env.example` to `.env` and fill in your DB credentials + a random secret key:
   ```bash
   cp .env.example .env
   ```

3. Install dependencies:
   ```bash
   python3 -m venv venv
   source venv/bin/activate      # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

4. Run the API:
   ```bash
   uvicorn app.main:app --reload
   ```

5. Open interactive API docs at: http://127.0.0.1:8000/docs

## What's included (Week 1 scope)

- `POST /auth/register` — create a user (researcher, institution_admin, reviewer, system_admin)
- `POST /auth/login` — returns JWT access token
- `POST /researchers/me` — create your researcher profile (requires auth token)
- `GET /researchers/me` — view your own profile
- `PUT /researchers/me` — update your profile
- `GET /researchers/{id}` — view any researcher's profile
- `GET /researchers/` — list all researchers
- `POST /institutions/` , `GET /institutions/` — minimal institution support (FK target only, full admin workflows are Milestone 2)

## Files

- `schema.sql` — raw PostgreSQL schema (reference / manual setup)
- `app/models/models.py` — SQLAlchemy ORM models (auto-creates tables on startup for dev)
- `app/routers/` — API endpoints
- `app/core/` — config, DB session, JWT/password security

## Not in scope for Week 1

Publications, conferences, citations, projects, and full institution management — these are Milestone 2/3 per the project timeline.
