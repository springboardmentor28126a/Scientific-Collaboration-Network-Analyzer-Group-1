from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import Researcher, User
from app.schemas.schemas import ResearcherCreate, ResearcherOut, ResearcherUpdate

router = APIRouter(prefix="/researchers", tags=["Researchers"])


@router.post("/me", response_model=ResearcherOut, status_code=201)
def create_my_profile(
    profile_in: ResearcherCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    existing = db.query(Researcher).filter(Researcher.user_id == current_user.id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Researcher profile already exists")

    profile = Researcher(user_id=current_user.id, **profile_in.model_dump())
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile


@router.get("/me", response_model=ResearcherOut)
def get_my_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    profile = db.query(Researcher).filter(Researcher.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Researcher profile not found")
    return profile


@router.put("/me", response_model=ResearcherOut)
def update_my_profile(
    profile_in: ResearcherUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    profile = db.query(Researcher).filter(Researcher.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Researcher profile not found")

    for field, value in profile_in.model_dump(exclude_unset=True).items():
        setattr(profile, field, value)

    db.commit()
    db.refresh(profile)
    return profile


@router.get("/{researcher_id}", response_model=ResearcherOut)
def get_researcher(researcher_id: int, db: Session = Depends(get_db)):
    profile = db.query(Researcher).filter(Researcher.id == researcher_id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Researcher not found")
    return profile


@router.get("/", response_model=list[ResearcherOut])
def list_researchers(skip: int = 0, limit: int = 20, db: Session = Depends(get_db)):
    return db.query(Researcher).offset(skip).limit(limit).all()
