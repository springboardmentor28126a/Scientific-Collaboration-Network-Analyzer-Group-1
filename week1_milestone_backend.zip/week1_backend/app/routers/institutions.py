from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.models import Institution
from app.schemas.schemas import InstitutionCreate, InstitutionOut

router = APIRouter(prefix="/institutions", tags=["Institutions"])

# Note: this is a lightweight Week 1 version, just enough to support
# researcher-institution linking. Full institution management
# (admin workflows, dashboards) belongs to Milestone 2.


@router.post("/", response_model=InstitutionOut, status_code=201)
def create_institution(inst_in: InstitutionCreate, db: Session = Depends(get_db)):
    inst = Institution(**inst_in.model_dump())
    db.add(inst)
    db.commit()
    db.refresh(inst)
    return inst


@router.get("/", response_model=list[InstitutionOut])
def list_institutions(db: Session = Depends(get_db)):
    return db.query(Institution).all()


@router.get("/{institution_id}", response_model=InstitutionOut)
def get_institution(institution_id: int, db: Session = Depends(get_db)):
    inst = db.query(Institution).filter(Institution.id == institution_id).first()
    if not inst:
        raise HTTPException(status_code=404, detail="Institution not found")
    return inst
