import enum

from sqlalchemy import (
    Column, BigInteger, String, Boolean, DateTime, ForeignKey, Text, Enum
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.core.database import Base


class UserRole(str, enum.Enum):
    researcher = "researcher"
    institution_admin = "institution_admin"
    reviewer = "reviewer"
    system_admin = "system_admin"


class User(Base):
    __tablename__ = "users"

    id = Column(BigInteger, primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False, default=UserRole.researcher)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    researcher = relationship("Researcher", back_populates="user", uselist=False)


class Institution(Base):
    __tablename__ = "institutions"

    id = Column(BigInteger, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    address = Column(Text, nullable=True)
    website = Column(String(255), nullable=True)
    country = Column(String(100), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    departments = relationship("Department", back_populates="institution")
    researchers = relationship("Researcher", back_populates="institution")


class Department(Base):
    __tablename__ = "departments"

    id = Column(BigInteger, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    institution_id = Column(BigInteger, ForeignKey("institutions.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    institution = relationship("Institution", back_populates="departments")
    researchers = relationship("Researcher", back_populates="department")


class Researcher(Base):
    __tablename__ = "researchers"

    id = Column(BigInteger, primary_key=True, index=True)
    user_id = Column(BigInteger, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    institution_id = Column(BigInteger, ForeignKey("institutions.id", ondelete="SET NULL"), nullable=True)
    department_id = Column(BigInteger, ForeignKey("departments.id", ondelete="SET NULL"), nullable=True)
    bio = Column(Text, nullable=True)
    orcid_id = Column(String(50), nullable=True)
    profile_picture_url = Column(String(500), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user = relationship("User", back_populates="researcher")
    institution = relationship("Institution", back_populates="researchers")
    department = relationship("Department", back_populates="researchers")
