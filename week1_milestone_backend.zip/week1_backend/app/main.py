from fastapi import FastAPI

from app.core.database import Base, engine
from app.routers import auth, researchers, institutions

# Creates tables automatically on startup (fine for dev; use Alembic migrations for production)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Scientific Collaboration Network Analyzer - API",
    description="Week 1 Milestone: Authentication, Researcher Profiles, Institutions",
    version="0.1.0",
)

app.include_router(auth.router)
app.include_router(researchers.router)
app.include_router(institutions.router)


@app.get("/")
def root():
    return {"status": "ok", "message": "SCN Analyzer API is running"}


@app.get("/health")
def health_check():
    return {"status": "healthy"}
