from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr


# ---------- Auth ----------
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    role: str = "researcher"


class UserOut(BaseModel):
    id: int
    email: EmailStr
    role: str
    is_active: bool

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


# ---------- Institution (minimal for Week 1) ----------
class InstitutionCreate(BaseModel):
    name: str
    country: Optional[str] = None


class InstitutionOut(BaseModel):
    id: int
    name: str
    country: Optional[str] = None

    class Config:
        from_attributes = True


# ---------- Researcher ----------
class ResearcherCreate(BaseModel):
    full_name: str
    institution_id: Optional[int] = None
    department_id: Optional[int] = None
    bio: Optional[str] = None
    orcid_id: Optional[str] = None


class ResearcherUpdate(BaseModel):
    full_name: Optional[str] = None
    institution_id: Optional[int] = None
    department_id: Optional[int] = None
    bio: Optional[str] = None
    orcid_id: Optional[str] = None


class ResearcherOut(BaseModel):
    id: int
    full_name: str
    institution_id: Optional[int] = None
    department_id: Optional[int] = None
    bio: Optional[str] = None
    orcid_id: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True
