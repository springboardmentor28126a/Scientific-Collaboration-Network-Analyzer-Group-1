-- ============================================================
-- Scientific Collaboration Network Analyzer
-- Database Schema (PostgreSQL)
-- Milestone 1 (Week 1-2) Scope: Users, Institutions, Departments, Researchers
-- Later-milestone tables included as forward-looking stubs (marked below)
-- ============================================================

-- Enable UUID generation (optional, using SERIAL/BIGSERIAL below for simplicity)
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- WEEK 1-2 CORE TABLES (YOUR DELIVERABLE)
-- ============================================================

-- ---------------------------------------------------
-- 1. ROLE ENUM
-- ---------------------------------------------------
CREATE TYPE user_role AS ENUM ('researcher', 'institution_admin', 'reviewer', 'system_admin');

-- ---------------------------------------------------
-- 2. USERS (Authentication)
-- ---------------------------------------------------
CREATE TABLE users (
    id              BIGSERIAL PRIMARY KEY,
    email           VARCHAR(255) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            user_role NOT NULL DEFAULT 'researcher',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    last_login_at   TIMESTAMP,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------
-- 3. INSTITUTIONS
-- ---------------------------------------------------
CREATE TABLE institutions (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    address         TEXT,
    website         VARCHAR(255),
    country         VARCHAR(100),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------
-- 4. DEPARTMENTS (belongs to an institution)
-- ---------------------------------------------------
CREATE TABLE departments (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    institution_id  BIGINT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------
-- 5. RESEARCHERS (profile, linked 1:1 with users)
-- ---------------------------------------------------
CREATE TABLE researchers (
    id                  BIGSERIAL PRIMARY KEY,
    user_id             BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    full_name           VARCHAR(255) NOT NULL,
    institution_id      BIGINT REFERENCES institutions(id) ON DELETE SET NULL,
    department_id       BIGINT REFERENCES departments(id) ON DELETE SET NULL,
    bio                 TEXT,
    orcid_id            VARCHAR(50),
    profile_picture_url VARCHAR(500),
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------
-- 6. RESEARCH INTERESTS (many-to-many: researcher <-> tags)
-- ---------------------------------------------------
CREATE TABLE research_interests (
    id      BIGSERIAL PRIMARY KEY,
    name    VARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE researcher_interests (
    researcher_id BIGINT NOT NULL REFERENCES researchers(id) ON DELETE CASCADE,
    interest_id   BIGINT NOT NULL REFERENCES research_interests(id) ON DELETE CASCADE,
    PRIMARY KEY (researcher_id, interest_id)
);

-- ---------------------------------------------------
-- 7. SKILLS (many-to-many: researcher <-> skills)
-- ---------------------------------------------------
CREATE TABLE skills (
    id      BIGSERIAL PRIMARY KEY,
    name    VARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE researcher_skills (
    researcher_id BIGINT NOT NULL REFERENCES researchers(id) ON DELETE CASCADE,
    skill_id      BIGINT NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    PRIMARY KEY (researcher_id, skill_id)
);

-- Indexes for Week 1-2 tables
CREATE INDEX idx_researchers_institution ON researchers(institution_id);
CREATE INDEX idx_researchers_department ON researchers(department_id);
CREATE INDEX idx_departments_institution ON departments(institution_id);
CREATE INDEX idx_users_email ON users(email);


-- ============================================================
-- FUTURE MILESTONE TABLES (STUBS ONLY - for reference,
-- so your Week-1 design already has clean foreign key paths.
-- Your team will build these out in Milestone 2 & 3)
-- ============================================================

-- ---------------------------------------------------
-- PUBLICATIONS (Milestone 2)
-- ---------------------------------------------------
CREATE TYPE publication_status AS ENUM ('draft', 'submitted', 'published', 'archived');
CREATE TYPE publication_type AS ENUM ('journal_paper', 'conference_paper', 'book', 'patent', 'technical_report');

CREATE TABLE publications (
    id              BIGSERIAL PRIMARY KEY,
    title           VARCHAR(500) NOT NULL,
    abstract        TEXT,
    type            publication_type NOT NULL,
    status          publication_status NOT NULL DEFAULT 'draft',
    doi             VARCHAR(150),
    publish_date    DATE,
    file_url        VARCHAR(500),
    created_by      BIGINT REFERENCES researchers(id) ON DELETE SET NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Co-authorship (many-to-many: researchers <-> publications)
CREATE TABLE publication_authors (
    publication_id  BIGINT NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
    researcher_id   BIGINT NOT NULL REFERENCES researchers(id) ON DELETE CASCADE,
    author_order    INT,
    PRIMARY KEY (publication_id, researcher_id)
);

-- ---------------------------------------------------
-- PROJECTS & COLLABORATIONS (Milestone 3)
-- ---------------------------------------------------
CREATE TABLE projects (
    id              BIGSERIAL PRIMARY KEY,
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    start_date      DATE,
    end_date        DATE,
    lead_researcher_id BIGINT REFERENCES researchers(id) ON DELETE SET NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE project_members (
    project_id      BIGINT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    researcher_id   BIGINT NOT NULL REFERENCES researchers(id) ON DELETE CASCADE,
    role_in_project VARCHAR(100),
    PRIMARY KEY (project_id, researcher_id)
);

CREATE TABLE institutional_collaborations (
    id                  BIGSERIAL PRIMARY KEY,
    institution_a_id    BIGINT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    institution_b_id    BIGINT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    project_id          BIGINT REFERENCES projects(id) ON DELETE SET NULL,
    started_at          DATE,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------
-- CONFERENCES (Milestone 2)
-- ---------------------------------------------------
CREATE TABLE conferences (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    location        VARCHAR(255),
    start_date      DATE,
    end_date        DATE,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE conference_participations (
    id              BIGSERIAL PRIMARY KEY,
    conference_id   BIGINT NOT NULL REFERENCES conferences(id) ON DELETE CASCADE,
    researcher_id   BIGINT NOT NULL REFERENCES researchers(id) ON DELETE CASCADE,
    publication_id  BIGINT REFERENCES publications(id) ON DELETE SET NULL,
    role            VARCHAR(100), -- e.g. presenter, attendee, panelist
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------
-- CITATIONS (Milestone 3)
-- ---------------------------------------------------
CREATE TABLE citations (
    id                      BIGSERIAL PRIMARY KEY,
    citing_publication_id   BIGINT NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
    cited_publication_id    BIGINT NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------
-- AUDIT LOGS (Milestone 4)
-- ---------------------------------------------------
CREATE TABLE audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT REFERENCES users(id) ON DELETE SET NULL,
    action          VARCHAR(255) NOT NULL,
    entity_type     VARCHAR(100),
    entity_id       BIGINT,
    details         JSONB,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ============================================================
-- END OF SCHEMA
-- ============================================================
